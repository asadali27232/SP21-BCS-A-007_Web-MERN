const productValidator = require('../validators/productValidator');

const validateProduct = (req, res, next) => {
    const { error } = productValidator.validate(req.body);
    if (error) {
        return res.status(400).send(error.details[0].message);
    }
    next();
};

module.exports = validateProduct;
